-- MySQL dump 10.13  Distrib 8.0.26, for Linux (x86_64)
--
-- Host: localhost    Database: coursemanagement
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fachbereich`
--

DROP TABLE IF EXISTS `fachbereich`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fachbereich` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fachbereich`
--

LOCK TABLES `fachbereich` WRITE;
/*!40000 ALTER TABLE `fachbereich` DISABLE KEYS */;
INSERT INTO `fachbereich` VALUES (1,'EDV'),(2,'Sprachen'),(3,'Betriebswirtschaft');
/*!40000 ALTER TABLE `fachbereich` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kurs`
--

DROP TABLE IF EXISTS `kurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kurs` (
  `kursnummer` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `beschreibung` text,
  `beginndatum` date NOT NULL,
  `dauer` int unsigned NOT NULL,
  `schwierigkeitsgrad_id` int unsigned NOT NULL,
  `fachbereich_id` int unsigned NOT NULL,
  `kursort_id` int unsigned NOT NULL,
  PRIMARY KEY (`kursnummer`),
  KEY `schwierigkeitsgrad_id` (`schwierigkeitsgrad_id`,`fachbereich_id`,`kursort_id`),
  KEY `fachbereich_id` (`fachbereich_id`),
  KEY `kursort_id` (`kursort_id`),
  CONSTRAINT `kurs_ibfk_1` FOREIGN KEY (`fachbereich_id`) REFERENCES `fachbereich` (`id`),
  CONSTRAINT `kurs_ibfk_2` FOREIGN KEY (`kursort_id`) REFERENCES `kursort` (`id`),
  CONSTRAINT `kurs_ibfk_3` FOREIGN KEY (`schwierigkeitsgrad_id`) REFERENCES `schwierigkeitsgrad` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kurs`
--

LOCK TABLES `kurs` WRITE;
/*!40000 ALTER TABLE `kurs` DISABLE KEYS */;
INSERT INTO `kurs` VALUES (1,'PHP Einführung','Einführung in PHP','2020-09-15',16,1,1,1),(2,'HTML & CSS','Einführung in HTML & CSS','2020-09-06',24,1,1,1),(3,'Englisch B2','Aufbaukurs für Englisch','2020-09-15',16,2,2,2);
/*!40000 ALTER TABLE `kurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kurs_teilnehmer`
--

DROP TABLE IF EXISTS `kurs_teilnehmer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kurs_teilnehmer` (
  `kursnummer` int unsigned NOT NULL,
  `teilnehmer_id` int unsigned NOT NULL,
  PRIMARY KEY (`kursnummer`,`teilnehmer_id`),
  KEY `teilnehmer_id` (`teilnehmer_id`),
  CONSTRAINT `kurs_teilnehmer_ibfk_1` FOREIGN KEY (`kursnummer`) REFERENCES `kurs` (`kursnummer`),
  CONSTRAINT `kurs_teilnehmer_ibfk_2` FOREIGN KEY (`teilnehmer_id`) REFERENCES `teilnehmer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kurs_teilnehmer`
--

LOCK TABLES `kurs_teilnehmer` WRITE;
/*!40000 ALTER TABLE `kurs_teilnehmer` DISABLE KEYS */;
INSERT INTO `kurs_teilnehmer` VALUES (1,1),(2,2),(1,3),(1,4);
/*!40000 ALTER TABLE `kurs_teilnehmer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kursort`
--

DROP TABLE IF EXISTS `kursort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kursort` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kursort`
--

LOCK TABLES `kursort` WRITE;
/*!40000 ALTER TABLE `kursort` DISABLE KEYS */;
INSERT INTO `kursort` VALUES (1,'Linz'),(2,'Perg'),(3,'Wels'),(4,'Steyr');
/*!40000 ALTER TABLE `kursort` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kurstermin`
--

DROP TABLE IF EXISTS `kurstermin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kurstermin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `kursnummer` int unsigned NOT NULL,
  `beginn` datetime NOT NULL,
  `dauer` int unsigned NOT NULL,
  `trainer_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kursnummer` (`kursnummer`),
  KEY `trainer_id` (`trainer_id`),
  CONSTRAINT `kurstermin_ibfk_1` FOREIGN KEY (`kursnummer`) REFERENCES `kurs` (`kursnummer`),
  CONSTRAINT `kurstermin_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `trainer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kurstermin`
--

LOCK TABLES `kurstermin` WRITE;
/*!40000 ALTER TABLE `kurstermin` DISABLE KEYS */;
INSERT INTO `kurstermin` VALUES (1,1,'2020-09-15 18:00:00',4,2),(2,1,'2020-09-17 18:00:00',4,2),(3,1,'2020-09-20 18:00:00',4,1),(4,1,'2020-09-22 18:00:00',4,1),(5,3,'2020-09-15 08:00:00',8,2),(6,3,'2020-09-16 08:00:00',8,2);
/*!40000 ALTER TABLE `kurstermin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schwierigkeitsgrad`
--

DROP TABLE IF EXISTS `schwierigkeitsgrad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schwierigkeitsgrad` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schwierigkeitsgrad`
--

LOCK TABLES `schwierigkeitsgrad` WRITE;
/*!40000 ALTER TABLE `schwierigkeitsgrad` DISABLE KEYS */;
INSERT INTO `schwierigkeitsgrad` VALUES (1,'Anfänger'),(2,'Fortgeschrittene'),(3,'Experten');
/*!40000 ALTER TABLE `schwierigkeitsgrad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teilnehmer`
--

DROP TABLE IF EXISTS `teilnehmer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teilnehmer` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `vorname` varchar(50) NOT NULL,
  `nachname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `geburtsdatum` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teilnehmer`
--

LOCK TABLES `teilnehmer` WRITE;
/*!40000 ALTER TABLE `teilnehmer` DISABLE KEYS */;
INSERT INTO `teilnehmer` VALUES (1,'Max','Mustermann','max.mustermann@test.at','1970-01-01'),(2,'Susi','Musterfrau','susi.musterfrau@test.at','1971-02-13'),(3,'Jane','Doe','jane.doe@test.com','1980-04-23'),(4,'John','Doe','john.doe@test.com','1982-06-22');
/*!40000 ALTER TABLE `teilnehmer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trainer`
--

DROP TABLE IF EXISTS `trainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trainer` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `vorname` varchar(50) NOT NULL,
  `nachname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainer`
--

LOCK TABLES `trainer` WRITE;
/*!40000 ALTER TABLE `trainer` DISABLE KEYS */;
INSERT INTO `trainer` VALUES (1,'Hans','Meister','hans.meister@test.at'),(2,'Nina','Müller','nina.mueller@test.at');
/*!40000 ALTER TABLE `trainer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-29 23:00:37
